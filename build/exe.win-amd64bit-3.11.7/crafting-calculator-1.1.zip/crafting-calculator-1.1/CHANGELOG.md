# 1.1
- Plus/Minus buttons added for quantities
- Added filter by recipe file as some of the files are getting quite large
- Lots more recipes added for Corepunk alchemy and weaponsmithing

# 1.03
- First release